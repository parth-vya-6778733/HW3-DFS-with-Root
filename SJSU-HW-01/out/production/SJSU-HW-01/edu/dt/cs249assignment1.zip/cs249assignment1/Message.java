package edu.dt;

/**
 * Created by tphadke on 8/29/17.
 */
public enum  Message {
    ALREADY ,PARENT, M;
}
